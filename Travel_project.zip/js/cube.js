//169.1
// function sumOfArr(arr) {
// 	let res = 0;
// 	for (let elem of arr) {
// 		res += elem;
// 	}
// 	return res / arr.length;
// }
// console.log(sumOfArr([123, 135, 31]));
//156.1
// function nameFunc(name) {
// 	console.log('Temirlan');
// }
// nameFunc();
//156.2
// function sumOfNum(arr) {
// 	let sum = 0;
// 	for (let i = 1; i <= 100; i++) {
// 		sum += i;
// 	}
// 	return sum;
// }
// console.log(sumOfNum());
//157.1 Параметры функций в JavaScript
function cube(num) {
	return Math.pow(num, 3);
}
console.log(cube(3));
console.log(cube(14));
